# assigment-1
print("Hello World") 
print('Hello World') 
print("You're a good man")
print('''You're a "good" person''')

# Q1: Write a Python program that prints the following text exactly as it appears: 

print("Python is fun.")
print('''"Quotes" and 'single quotes' can be tricky.''')
print("\"Quotes\" and 'single quotes' can be tricky.")

print("Python is fun.\n\"Quotes\" and 'single quotes' can be tricky.")

# Q2: For a business create 3 variables to store- name, age, and city. 
# Then print a sentence that uses these variables.
name = "Rishabh"
age = 26 
city = "Prayagraj" 
print("My name is", name, "from", city, "& I'm", age )

print(f"My name is {name} from {city} & I'm {age}")


